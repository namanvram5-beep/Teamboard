from django.contrib.auth.models import User
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from django.db import transaction
from django.db.models import Q
from .models import KBEntry, QueryLog
from django.db.models import Count
from .permissions import IsAdminUser

class RegisterView(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get("username")
        password = request.data.get("password")
        company_name = request.data.get("company_name")
        email = request.data.get("email")

        if User.objects.filter(username=username).exists():
            return Response(
                {"error": "Username already exists"},
                status=status.HTTP_400_BAD_REQUEST
            )

        user = User.objects.create_user(
            username=username,
            password=password,
            email=email
        )

        company = user.company
        company.company_name = company_name
        company.save()

        refresh = RefreshToken.for_user(user)

        return Response({
            "username": user.username,
            "company_name": company.company_name,
            "api_key": company.api_key,
            "access": str(refresh.access_token)
        }, status=status.HTTP_201_CREATED)



class LoginView(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get("username")
        password = request.data.get("password")

        user = authenticate(username=username, password=password)

        if user is None:
            return Response(
                {"error": "Invalid credentials"},
                status=status.HTTP_401_UNAUTHORIZED
            )

        company = user.company
        refresh = RefreshToken.for_user(user)

        return Response({
            "access": str(refresh.access_token),
            "company_name": company.company_name,
            "api_key": company.api_key
        }, status=status.HTTP_200_OK)


class KBQueryView(APIView):
    def post(self, request):
        search_term = request.data.get("search")

        if not search_term or not search_term.strip():
            return Response(
                {"error": "Search field is required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        company = request.user.company

        with transaction.atomic():
            results = KBEntry.objects.filter(
                Q(question__icontains=search_term) |
                Q(answer__icontains=search_term)
            )

            count = results.count()

            QueryLog.objects.create(
                company=company,
                search_term=search_term,
                results_count=count
            )

        data = []
        for item in results:
            data.append({
                "id": item.id,
                "question": item.question,
                "answer": item.answer,
                "category": item.category
            })

        return Response({
            "search": search_term,
            "count": count,
            "results": data
        }, status=status.HTTP_200_OK)

class UsageSummaryView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        total_queries = QueryLog.objects.aggregate(
            total=Count('id')
        )['total']

        active_companies = QueryLog.objects.values(
            'company'
        ).distinct().count()

        top_search_terms = QueryLog.objects.values(
            'search_term'
        ).annotate(
            count=Count('id')
        ).order_by('-count')[:5]

        return Response({
            "total_queries": total_queries,
            "active_companies": active_companies,
            "top_search_terms": list(top_search_terms)
        })